import PySimpleGUI as sg
from pathlib import Path
import chardet
sg.theme("LightBlue2")

layout =[[sg.B("新規作成",k="btn1"),sg.B("ファイルを開く",k="btn2"),sg.T(k="txt1")],
         [sg.B("保存する",k="btn3")],
         [sg.ML(k="txt2",font=(None,14),size=(80,15))]]

win =sg.Window("テキストファイルの読み込み",layout)
    

def loadtext():
    global loadname,enc
    loadname=sg.popup_get_file("テキストファイルを選択してください")
    if not loadname:
        return
    with open(loadname,"rb") as f:
        b=f.read()
        enc=chardet.detect(b)["encoding"]
        p=Path(loadname)
        txt=p.read_text(encoding=enc)
        win["txt1"].update(loadname)
        win["txt2"].update(txt)

def newtext():
    global loadname,enc
    loadname=None
    enc="utf-8"
    win["txt1"].update("新規ファイル")
    win["txt2"].update("")

def savetext():
    global loadname,enc

    if loadname is None:
        loadname=sg.popup_get_file("新規ファイル名を入力してください",
                                   save_as=True,default_extension=".txt")
        if not loadname:
            sg.popupTimed("ファイル名を入力してください")
            return

    savename=sg.popup_get_file("名前を付けて保存してください",
                               default_path=loadname,save_as=True)

                                       
    if not savename:
        sg.PopupTimed("ファイル名を入力してください")
        return

    if savename.find(".")==-1:
        savename=savename + ".txt"

    Path(savename).write_text(win["txt2"].get(),encoding=enc)

    loadname=savename
    win["txt1"].update(loadname)
    sg.popup("保存しました")


while True:
    e,v=win.read()
    if e=="btn1":
        newtext()
    if e=="btn2":
        loadtext()
    if e=="btn3":
        savetext()
    if e==None:
        break

win.close()
